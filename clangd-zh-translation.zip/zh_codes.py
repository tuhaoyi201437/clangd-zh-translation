# -*- coding: utf-8 -*-
"""clangd 诊断码 -> 中文(优先于文本规则，最稳)。

键是 clangd LSP 里的 diagnostic.code(TableGen 诊断名去掉 err_/warn_ 前缀)。
值里的 {1} {2} ... 会自动填入英文消息中按顺序出现的 '单引号内容'，
带引号一起填入，例如 {1} -> 'foo'。

想加规则：照着写一行 "code": "中文，变量 {1} 在这里" 即可。
"""
CODE_RULES = {
    # 语法 / 期望
    # 错误过多时的收尾提示(clangd 会停止继续报告)
    "fatal_too_many_errors": "错误太多,已停止继续报告(先修前面的错误，后面的错误不再显示)",
    "expected": "此处需要 {1}",
    "expected_either": "此处需要 {1} 或 {2}",
    "expected_after": "{1} 之后需要 {2}",
    "invalid_token_after_toplevel_declarator": "全局声明末尾缺少分号 ';'",
    "expected_semi_declaration": "声明末尾缺少分号 ';'",
    "expected_semi_after_expr": "表达式后缺少分号 ';'",
    "expected_semi_after_stmt": "语句后缺少分号 ';'",
    "expected_semi_after_for": "for 语句中缺少分号 ';'",
    "expected_semi_after_namespace": "命名空间定义末尾缺少分号 ';'",
    # 构造函数初始化列表漏写 ':' 时 clang 报的就是这条
    "expected_semi_decl_list": "声明列表末尾缺少分号 ';'",
    # using namespace std; 但标准头文件没找到时会连带报这条
    "ext_using_undefined_std": "using 指令引用了隐式定义的命名空间 'std'"
                                "(通常表示没有包含对应的标准头文件)",
    "expected_expression": "此处需要一个表达式",
    # 在表达式位置写了类型名,例如 auto x = nullptr_t;(应为 std::nullptr_t{} 或值)
    "unexpected_typedef": "此处应为表达式，却出现了类型名 {1}(检查是否漏写构造调用或 std:: 限定)",
    # 对没有重载 ++/-- 的类型做自增/自减
    "typecheck_illegal_increment_decrement": "不能对类型 {1} 的值做自增/自减(该类型没有 ++/-- 运算符)",
    # lambda 少写函数体,例如 [](int a) a + 1
    "expected_lambda_body": "此处缺少 lambda 表达式的函数体(要写成 { 语句 } 的形式)",
    "expected_statement": "此处需要一条语句",
    "expected_lparen": "此处需要左括号 '('",
    "expected_rparen": "缺少右括号 ')'",
    "expected_lbrace": "此处需要左花括号 '{'",
    "expected_rbrace": "缺少右花括号 '}'",
    "expected_rsquare": "缺少右方括号 ']'",
    "expected_unqualified_id": "此处需要一个标识符",
    "expected_parameter_declarator": "此处需要参数声明",
    "expected_namespace_name": "此处需要命名空间名",
    "expected_class_name": "此处需要类名",
    "expected_type": "此处需要一个类型",
    "expected_identifier": "此处需要一个标识符",
    "expected_colon": "此处需要冒号 ':'",
    "expected_comma": "此处需要逗号 ','",
    "expected_string_literal": "此处需要字符串字面量",
    "expected_eof": "文件末尾有多余内容",
    "extraneous_closing_brace": "多余的右花括号 '}'",
    "extraneous_token_instead_of": "多余的 {1}，此处应为 {2}",
    "missing_type_specifier": "缺少类型说明符(将默认为 'int')",
    "invalid_decl_spec_combination": "不能与前面的 {1} 类型说明符组合使用(是否重复写了类型？)",
    "unterminated_string": "字符串字面量缺少结束引号",
    "unterminated_char": "字符字面量缺少结束引号",
    "unterminated_comment": "注释没有结束符",
    "unknown_escape": "未知的转义序列 {1}",
    "invalid_escape": "无效的转义序列 {1}",

    # 未声明 / 未知
    "undeclared_var_use": "使用了未声明的标识符 {1}(检查拼写、声明或头文件)",
    "undeclared_var_use_suggest": "使用了未声明的标识符 {1}(是否想写 {2}？)",
    "undeclared_function_use": "使用了未声明的函数 {1}",
    "undeclared_label_use": "使用了未声明的标签 {1}",
    "unknown_typename": "未知的类型名 {1}",
    "unknown_typename_suggest": "未知的类型名 {1}(是否想写 {2}？)",
    "unknown_type_or_class_name_suggest": "未知的类型或类名 {1}(是否想写 {2}？)",
    "unknown_template_name": "未知的模板名 {1}",
    "no_member": "{2} 中没有名为 {1} 的成员",
    "no_member_suggest": "{2} 中没有名为 {1} 的成员(是否想写 {3}？)",
    "no_type": "{2} 中没有名为 {1} 的类型",
    "no_template": "没有名为 {1} 的模板",
    "no_template_suggest": "没有名为 {1} 的模板(是否想写 {2}？)",
    "no_member_in_namespace": "命名空间 {2} 中没有名为 {1} 的成员",
    "not_class_namespace_or_enumeration": "{1} 不是类、命名空间或枚举，不能用 '::'",

    # 类型 / 转换 / 表达式
    "init_conversion_failed": "无法用类型 {2} 的值初始化类型 {1} 的变量",
    "typecheck_converted_constant_expression": "{1} 不能隐式转换为 {2}",
    "typecheck_nonviable_condition": "返回值类型 {1} 无法转换为函数返回类型 {2}",
    "typecheck_invalid_operands": "二元运算的操作数类型不合法({1} 和 {2})",
    "typecheck_invalid_operands_suggest": "二元运算的操作数类型不合法({1} 和 {2})，是否想写 {3}？",
    "typecheck_comparison_of_distinct_pointer_types": "比较了不同类型的指针({1} 与 {2})",
    "typecheck_assign_const": "不能给 const 限定的变量 {1} 赋值",
    "typecheck_assign_const_rvalue": "不能给 const 限定的对象赋值",
    "typecheck_expression_not_modifiable_lvalue": "该表达式不能被赋值(不是可修改的左值)",
    "typecheck_array_not_modifiable_lvalue": "数组类型 {1} 不能被整体赋值",
    "typecheck_decl_incomplete_type": "变量的类型 {1} 不完整(是否只有前置声明？)",
    "typecheck_incomplete_type": "类型 {1} 不完整，不能做此操作",
    "typecheck_member_reference_struct_union": "{1} 不是结构体或类，不能用 '.' 访问成员",
    "typecheck_member_reference_arrow": "{1} 不是指针，不能用 '->' 访问成员",
    "typecheck_subscript_value": "下标运算的对象不是数组、指针或 vector",
    "typecheck_subscript_not_integer": "数组下标必须是整数类型",
    "typecheck_called_object_type": "{1} 不是函数或函数指针，不能调用",
    "typecheck_return_incompatible": "返回值类型 {1} 与函数返回类型 {2} 不兼容",
    "typecheck_return_void": "void 函数不应返回值",
    "typecheck_missing_return": "非 void 函数可能执行到末尾而没有返回值",
    "typecheck_bool_condition": "{1} 不能用作条件表达式",
    "typecheck_arithmetic_incomplete_type": "不能对不完整类型 {1} 做算术运算",
    "typecheck_pointer_arithmetic": "不能对 {1} 做指针算术",
    "typecheck_invalid_cast": "从 {1} 到 {2} 的强制转换不合法",
    "typecheck_indirection_through_pointer": "{1} 不是指针，不能解引用",
    "typecheck_deref_incomplete_type": "不能解引用不完整类型 {1} 的指针",
    "typecheck_addrof_incomplete_type": "不能对不完整类型 {1} 取地址",
    "sizeof_incomplete_type": "不能对不完整类型 {1} 使用 sizeof",
    "lvalue_reference_bind_to_temporary": "非 const 左值引用 {1} 不能绑定到临时对象 {2}",
    "reference_bind_failed": "无法把 {2} 绑定到 {1} 类型的引用",
    "init_list_bin_op": "初始化列表不能出现在二元运算符的右侧(宏展开后往往少了括号)",
    "invalid_use_of_incomplete_type": "不能对不完整类型 {1} 做此操作",

    # 函数 / 重载
    "ovl_no_viable_function_in_call": "没有与调用 {1} 匹配的函数(检查参数个数与类型)",
    "ovl_no_viable_member_function_in_call": "没有与调用 {1} 匹配的成员函数",
    "ovl_no_viable_object_call": "没有与 {1} 匹配的可调用形式(函数对象或 lambda 的参数不匹配)",
    "ovl_ambiguous_call": "对 {1} 的调用有歧义",
    "ovl_deleted_call": "调用了已删除的函数 {1}",
    "typecheck_call_too_few_args": "函数调用的参数太少",
    "typecheck_call_too_many_args": "函数调用的参数太多",
    "typecheck_call_too_few_args_suggest": "函数调用的参数太少(是否想调用 {1}？)",
    "param_redefinition": "参数 {1} 被重复定义",
    "out_of_line_definition_mismatch": "{1} 的类外定义与 {2} 中的声明不匹配",
    "function_definition_not_allowed": "此处不允许定义函数",
    "conflicting_return_type": "函数返回类型与先前声明冲突",
    "redefinition": "{1} 被重复定义",
    "redeclaration": "{1} 被重复声明",
    "duplicate_case": "重复的 case 值 {1}",
    "duplicate_case_prev": "重复的 case 值 {1}(前面已出现过)",
    "duplicate_label": "重复的标签 {1}",
    "duplicate_member": "重复的成员 {1}",
    "shadow": "该声明遮蔽了外层的 {1}",
    "access": "{1} 是 {2} 的私有/受保护成员，不能访问",

    # 初始化 / 数组
    "excess_initializers": "数组初始化列表中的元素过多",
    "excess_initializers_in_char_array": "字符数组初始化列表中的元素过多",
    "default_init_const": "{1} 类型的 const 对象必须初始化",
    "array_too_large": "数组尺寸过大",
    "zero_size_array": "数组大小不能为 0",
    "negative_array_size": "数组大小不能为负数",
    "variable_length_array": "变长数组不是标准 C++",
    "invalid_array_size": "数组大小必须是整数常量表达式",
    "array_init_too_many": "初始化列表元素多于数组长度",
    "scalar_initializer": "标量类型的初始化列表元素过多",

    # 预处理 / 文件
    "pp_file_not_found": "找不到头文件 {1}(检查文件名与包含路径)",
    "pp_error": "预处理错误：{1}",
    "pp_hash_error": "#error: {1}",
    "pp_eof": "预处理指令未结束",
    "pp_through_header_not_found": "预编译头需要的 {1} 找不到",
    "pp_division_by_zero": "预处理表达式中除以零",

    # 控制流
    "break_not_in_loop_or_switch": "'break' 只能用在循环或 switch 语句中",
    "continue_not_in_loop": "'continue' 只能用在循环中",
    "return_not_in_function": "'return' 只能用在函数里",
    "default_not_in_switch": "'default' 只能用在 switch 语句中",
    "case_not_in_switch": "'case' 只能用在 switch 语句中",
    "goto_into_scope": "goto 跳过了变量初始化，不允许",
    "jump_bypass_init": "跳转绕过了 {1} 的初始化",
    "unreachable_code": "不可达代码",

    # 常见警告
    "unused_variable": "变量 {1} 定义了但没有使用",
    "unused_parameter": "参数 {1} 没有被使用",
    "unused_function": "函数 {1} 定义了但没有使用",
    "unused_const_variable": "常量 {1} 定义了但没有使用",
    "unused_result": "表达式的结果没有被使用",
    "uninitialized": "变量 {1} 在使用时还未初始化",
    "maybe_uninitialized": "变量 {1} 可能未初始化",
    "sign_compare": "有符号与无符号整数比较({1} 与 {2})",
    "sign_conversion": "有符号与无符号整数之间的隐式转换({1} 与 {2})",
    "division_by_zero": "除以零是未定义行为",
    "infinite_recursive_function": "函数 {1} 会无限递归调用自身",
    "parentheses": "建议加括号明确运算优先级",
    "assignment_in_condition": "条件表达式里用了赋值 '='(是否想写 '=='？)",
    "self_assignment": "变量给自己赋值",
    "unreachable": "不可达代码",
    "format": "格式字符串与参数类型不匹配(期望 {1}，实参 {2})",
    "-Wformat-invalid-specifier": "格式字符串中有无效的转换说明符 {1}(检查 '%' 后面是否漏写了字母或把转义写错)",
    "deprecated": "{1} 已弃用",
    "multichar": "多字符字符常量(通常应使用字符串)",
    "empty_char": "空的字符常量",
    "implicit_conversion_floating_to_integer": "浮点数到整数的隐式转换可能丢失精度",

    # 模板 / 静态断言
    "too_few_template_arguments": "模板参数太少",
    "too_many_template_arguments": "模板参数太多",
    "template_arg_must_be_type": "模板参数必须是类型",
    "template_arg_type_mismatch": "模板参数类型不匹配",
    "template_deduction_failure": "模板参数推导失败",
    "use_of_class_template_requires_template_args": "使用类模板 {1} 时必须写出模板参数",
    "typename_requires_qualified": "'typename' 只能用于限定名",
    "using_requires_qualname": "using 声明需要限定名(应写成 'using 命名空间::名字;' 或 'using namespace 命名空间;')",
    "ovl_unresolvable": "无法解析对重载函数的引用(是否想调用它？)",
    "static_assert_failed": "静态断言失败",
    "static_assert_requirement": "静态断言失败：条件 {1} 不成立",
    "no_matching_template": "没有匹配的模板",
    "template_instantiation_failed": "模板实例化失败",
    "iso_cxx_standard": "当前 C++ 标准不允许 {1}",

    # ---- 警告族：警告的 code 是 -Wxxx 编译选项名，错误才是 TableGen 诊断名 ----
    "-Wunused-value": "表达式的结果没有被使用(这条语句没有产生任何效果)",
    "-Wunused-comparison": "相等比较的结果没有被使用(是否想写赋值 '='？)",
    "-Wunused-result": "函数的返回值没有被使用(调用结果被丢弃)",
    "-Wunused-variable": "变量 {1} 定义了但没有使用",
    "-Wunused-but-set-variable": "变量 {1} 被赋值过但从未使用",
    "-Wunused-const-variable": "常量 {1} 定义了但没有使用",
    "-Wunused-parameter": "参数 {1} 没有被使用",
    "-Wunused-function": "函数 {1} 定义了但没有使用",
    "-Wunused-label": "标签 {1} 定义了但没有使用",
    "-Wunused-private-field": "私有成员 {1} 没有被使用",
    "-Wunused-local-typedef": "局部类型别名 {1} 定义了但没有使用",
    "-Wuninitialized": "变量 {1} 未初始化就被使用",
    "-Wsometimes-uninitialized": "变量 {1} 可能未初始化就被使用",
    "-Wconditional-uninitialized": "变量 {1} 在某些分支下可能未初始化",
    "-Wparentheses": "把赋值表达式直接当条件使用，建议加括号(是否想写 '=='？)",
    "-Wsign-compare": "有符号与无符号整数比较：{1} 与 {2}",
    "-Wreturn-type": "非 void 函数缺少 return 语句(没有返回值)",
    "-Wreturn-mismatch": "非 void 函数 {1} 应该返回一个值",
    "-Wempty-body": "if / 循环语句的语句体是空的(把分号单独放一行可消除此警告)",
    "-Winfinite-recursion": "函数会无限递归调用自己",
    "-Wformat": "格式化字符串与传入的参数类型不匹配",
    "-Wtautological-compare": "这个比较的结果恒为真或恒为假",
    "-Wdivision-by-zero": "除数为零",
    "-Wswitch": "switch 语句没有处理所有枚举值",
    "-Wshadow": "此声明遮蔽了外层的同名变量",
    "-Wdeprecated-declarations": "使用了已弃用的 {1}",
    "-Wnull-dereference": "可能对空指针解引用",
    "-Wlogical-not-parentheses": "逻辑非 '!' 的作用范围可能不符预期，建议加括号",
    "-Wdangling-else": "else 的配对可能有歧义，建议加大括号",
    "-Wmacro-redefined": "宏 {1} 被重复定义(检查是否写了两份 #define)",
    "-Wundef": "#if 中使用了未定义的宏",
    "-Wfloat-equal": "浮点数直接用 == 比较可能有精度问题",
    "-Wconstant-conversion": "常量转换会丢失数据",
    "-Wimplicit-int-conversion": "隐式整数转换可能改变数值",
    "-Wmissing-declarations": "这个声明没有声明任何内容(是否漏写了变量名？)",

    # ---- 对照《C++常见的编译错误中英对应翻译》补充(clangd 真实诊断码，非 MSVC 的 Cxxxx)----
    "-Wc99-extensions": "宏名与替换内容之间必须有空格(C99 规定)",
    "array_incomplete_or_sizeless_type": "数组的元素类型 {1} 不完整(定义多维数组时不能省略后面的维度)",
    "character_not_allowed_identifier": "标识符中不允许出现这个字符(通常是误输入了中文标点，例如中文分号)",
    "exponent_has_no_digits": "浮点数的指数部分缺少数字(例如 1.23E 后面必须写数字)",
    "initializer_string_for_char_array_too_long": "用来初始化的字符串超出了 char 数组长度(数组太小，别忘了结尾的 '\\0')",
    "invalid_digit": "数字 {1} 在这个进制的常量中不合法(八进制里不能出现 8 或 9)",
    "pp_duplicate_name_in_arg_list": "带参宏的形式参数名 {1} 重复了",
    "pp_expected_comma_in_arg_list": "带参宏的参数列表中缺少逗号 ','(或混入了非法字符)",
    "pp_expects_filename": "#include 后面需要文件名，要写成 \"xxx.h\" 或 <xxx.h>",
    "pp_missing_macro_name": "#define 后面缺少宏名",
    "typecheck_converted_constant_expression_disallowed": "常量表达式中不允许把 {1} 转换成 {2}",
    "typecheck_statement_requires_integer": "这条语句要求整数类型的表达式，{1} 不合法",
    "warn_char_constant_too_large": "字符常量太长，超出了该类型能容纳的范围",
}

# 少数需要精确提取的诊断码：(英文正则, 中文模板)，优先级高于 CODE_RULES。
# 正则用 search，能容忍消息尾部的 "(fix available)" 等附加内容。
CODE_EXACT = {
    "expected_semi_declaration": (r"expected ';' at end of declaration", "声明末尾缺少分号 ';'"),
    "expected_expression": (r"expected expression", "此处需要一个表达式"),
    "pp_file_not_found": (r"'(.+?)' file not found", r"找不到头文件 '\1'(检查文件名与包含路径)"),
    "undeclared_var_use_suggest": (r"use of undeclared identifier '(.+?)'; did you mean '(.+?)'\?",
                                  r"使用了未声明的标识符 '\1'(是否想写 '\2'？)"),
    # 构造初始化失败：clangd 会把候选 note 拼进同一个 message 的多行里。
    # 代理按行翻译，这里的 (.*) 只吃到本行末尾，后续 note 行交给 NOTE_RULES。
    "ovl_no_viable_function_in_init": (
        r"no matching constructor for initialization of '(.+?)'( \(aka '[^']*'\))?(.*)",
        r"没有可用于初始化 '\1' 的构造函数\2\3"),
    # 以下几条同样会拼接 note，按行翻译后 (.*) 为空，不会吞掉后面的提示。
    "-Wvla-cxx-extension": (
        r"variable length arrays in c\+\+ are a clang extension(.*)",
        r"C++ 标准不允许变长数组(这是 Clang 扩展)，数组长度必须是编译期常量\1"),
    "expr_not_cce": (
        r"case value is not a constant expression(.*)",
        r"case 后面的值不是常量表达式(必须能在编译期确定)\1"),
    "multiple_default_labels_defined": (
        r"multiple default labels in one switch(.*)",
        r"同一个 switch 中出现了多个 default 分支\1"),
    # 头文件内重定义编译器内置函数(常见于 #define int long long 之类的宏污染)
    "builtin_definition": (
        r"definition of builtin function '(.+?)'",
        r"定义了与编译器内置函数同名的函数 '\1'(检查 #define 宏或头文件包含顺序)"),
    # 初始化列表出现在二元运算符右侧(宏展开常见)，保留具体运算符名
    "init_list_bin_op": (
        r"initializer list cannot be used on the right hand side of operator '(.+?)'",
        r"初始化列表不能出现在运算符 '\1' 的右侧(宏展开后往往少了括号)"),
    # 位域宽度超过类型能表示的范围(clang 的 -Wbitfield-width)
    "bitfield_width_exceeds_type_width": (
        r"width of bit-field '(.+?)' \((\d+) bits?\) exceeds the size of its type \((\d+) bits?\)",
        r"位域 '\1' 的宽度(\2 位)超过了其类型能表示的宽度(\3 位)"),

}

# ==================================================================
# 「note 同步翻译」时补的诊断码(真实 clangd 23.1.0 报错样本采集)。
# 独立成块，由代理合并进 CODE_RULES，不改动上面的原有条目。
# ==================================================================
EXTRA_CODE_RULES = {
    "access_ctor": "调用了类 {1} 的 protected/private 构造函数(不能从外部构造对象)",
    "sizeof_alignof_incomplete_or_sizeless_type": "不能对不完整类型使用 sizeof / alignof(类型只有前置声明)",
    "goto_into_protected_scope": "goto 不能跳到该标签(会跳过变量初始化)",
    "ovl_deleted_init": "调用了 {1} 已被删除的构造函数",
    "ovl_deleted_call": "调用了 {1} 已被删除的函数",
    "-Wc++11-narrowing": "初始化列表中不能把 {1} 窄化为 {2}(会丢失数据)",
    "-Wliteral-conversion": "从 {1} 到 {2} 的隐式转换改变了数值",
    "-Wswitch": "switch 语句没有处理所有枚举值({1} 未处理)",
    "unused-includes": "包含的头文件 {1} 未被直接使用",
    "-Wbitfield-width": "位域 {1} 的宽度超过了其类型能表示的宽度",
    "access_ctor_derived": "基类构造函数受保护，不能在派生类外调用",
    # ---- 2026-11-23 批量补：来自本地未命中日志复核 ----
    "expected_lparen_after": "此处需要左括号 '('",
    "expected_member_name_or_semi": "声明说明符后需要成员名或分号 ';'",
    "bound_member_function": "引用了非静态成员函数，必须调用它(函数名后要加 ())",
    "typecheck_unary_expr": "一元运算的操作数类型 {1} 不合法",
    "-Wreserved-user-defined-literal": "字面量后缀不合法：C++11 要求字面量与标识符之间有空格",
    "-Winvalid-pp-token": "字符字面量缺少结束的单引号 '",
    "subscript_function_type": "不能对函数指针类型 {1} 使用下标运算",
    "member_redeclared": "类成员不能重复声明",
    "addr_ovl_no_viable": "重载函数 {1} 的地址与需要的类型 {2} 不匹配",
    "redefinition_different_type": "{1} 被重复定义且类型不同：{2} 与 {3}",
    "ovl_no_oper": "类型 {1} 不提供调用运算符(不能当函数调用)",
    "-Woverloaded-shift-op-parentheses": "重载的 >> 运算符优先级高于比较运算符，建议加括号",
    "typecheck_convert_pointer_int": "不能把指针 {2} 赋给整数 {1}",
    "-Wpointer-bool-conversion": "数组或函数的地址恒为 true(永远为真)",
    "attributes_not_allowed": "这里不允许出现属性列表",
    "extraneous_token_before_semi": "分号 ';' 前有多余的 {1}",
    "lambda_impcap": "变量 {1} 无法在无默认捕获方式的 Lambda 中隐式捕获(应写成 '[=]'/'[&]' 或把 {1} 加入捕获列表)",
    "integer_literal_too_large": "整数字面量过大，无法用任何标准整数类型表示(考虑改用 __int128、大整数库或字符串处理)",
}
